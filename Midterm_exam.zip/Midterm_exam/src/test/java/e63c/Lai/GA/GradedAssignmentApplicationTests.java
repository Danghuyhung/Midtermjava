package e63c.Lai.GA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GradedAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
